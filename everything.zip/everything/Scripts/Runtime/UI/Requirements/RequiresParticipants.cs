using UnityEngine.XR.ARSubsystems;

namespace UnityEngine.XR.ARFoundation.Samples
{
    public class RequiresParticipants : RequiresARSubsystem<XRParticipantSubsystem, XRParticipantSubsystemDescriptor>
    { }
}
