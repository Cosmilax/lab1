#if VISUALSCRIPTING_1_8_OR_NEWER
using UnityEngine.Scripting;

[assembly: AlwaysLinkAssembly, Preserve]
#endif
