using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;


public class Restore : MonoBehaviour
{
    public GameObject Restore1;
    public GameObject shirt1;
    public GameObject Restore2;
    public GameObject shirt2;
    public GameObject Restore3;
    public GameObject shirt3;
    public GameObject Restore4;
    public GameObject shirt4;
    public GameObject Restore5;
    public GameObject pants1;
    public GameObject Restore6;
    public GameObject pants2;
    public GameObject Restore7;
    public GameObject pants3;
    public GameObject Restore8;
    public GameObject pants4;

    // Start is called before the first frame update
    public void Restoreicon1()
    {
        if (shirt1.activeSelf == false)
        {
            Restore1.SetActive(true);

        }
    }
        public void Restoreicon2()
        {
            if (shirt2.activeSelf == false)
            {
                Restore2.SetActive(true);

            }
        }
        public void Restoreicon3()
        {
            if (shirt3.activeSelf == false)
            {
                Restore3.SetActive(true);

            }
        }
        public void Restoreicon4()
        {
            if (shirt4.activeSelf == false)
            {
                Restore4.SetActive(true);

            }
        }
        public void Restoreicon5()
        {
            if (pants1.activeSelf == false)
            {
                Restore5.SetActive(true);

            }   
        }
        public void Restoreicon6()
        {
            if (pants2.activeSelf == false)
            {
                Restore6.SetActive(true);

            }
        }
        public void Restoreicon7()
        {
            if (pants3.activeSelf == false)
            {
                Restore7.SetActive(true);

            }
        }
        public void Restoreicon8()
        {
            if (pants4.activeSelf == false)
            {
                Restore8.SetActive(true);

            }
        }

    }
    
